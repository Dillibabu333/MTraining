import './App.css';
import Registration from './Registration';

function App() {
  return (
    <div className="App">
     <Registration/>
  
    </div>
  );
}

export default App;

import React, { useState,  } from 'react'
import "./Registration.css";
import axios from 'axios';



const Registration = () => {
    const [formdata, setFormdata]=useState({
        fname:"",
        desg:"",
        email:'',
        phno:"",
        password:"",
    })

  
    const handleChange = (e) => {
        const { name, value } = e.target;
    
        setFormdata({
          ...formdata,
          [name]: value,
        });
      };
    
      const handleSubmit = async (e) => {
        e.preventDefault();
        try {
          console.log('Form Data:', formdata);
          // Send formData to backend
          await axios.post('http://localhost:5000/contacts', formdata);
      
          // Redirect on success
        } catch (err) {
          console.error('Error:', err.response.data); 
      
          window.alert(`Error: ${err.response.data.error}`);
        }
      };
      
  return (
    <div className='registration'>
    <h2 className="heading">Registration Form</h2>
    <form onClick={handleSubmit} className="form" action="">
        <label  htmlFor="name">Name*</label> <br />
        <input type="text" placeholder='Enter name' name='fname' value={formdata.fname}  onChange={handleChange} required/><br /><br />
        
        <label htmlFor="name">Designation*</label><br />
        <input type="text" placeholder='Enter designation' name='desg' value={formdata.desg} onChange={handleChange} required/><br /><br />

        <label htmlFor="name">Email*</label><br />
        <input type="text" placeholder='Enter email' name='email' value={formdata.email} onChange={handleChange} required/><br /><br />
        <label htmlFor="name">Phone Number</label><br />
        <input type="text" placeholder='Enter phone number' name='phno' value={formdata.phno} onChange={handleChange} required/><br /><br />

        <label htmlFor="name">Password*</label><br />
        <input type="text" placeholder='Enter password' name='password' value={formdata.password}  onChange={handleChange}/><br /><br />
        <button className="submit" type="submit">Submit</button>
    </form>
    </div>
  )
}

export default Registration